# Squares - Complex example

An example of a more featureful chess app built with Squares.