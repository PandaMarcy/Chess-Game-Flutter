import 'dart:math';

import 'package:squares_complex/board_editor_view.dart';
import 'package:squares_complex/game_config.dart';
import 'package:flutter/material.dart';
import 'package:bishop/bishop.dart' as bishop;
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:squares/squares.dart';

class GameCreator extends StatefulWidget {
  final PieceSet pieceSet;
  final Function(GameConfig) onCreate;
  const GameCreator({
    super.key,
    required this.pieceSet,
    required this.onCreate,
  });

  @override
  State<GameCreator> createState() => _GameCreatorState();
}

class _GameCreatorState extends State<GameCreator> {
  List<bishop.Variant> variants = [
    bishop.Variant.standard(),
    bishop.Variant.mini(),
    bishop.Variant.micro(),
    bishop.Variant.grand(),
  ];

  List<DropdownMenuItem<int>> get _variantDropdownItems {
    List<DropdownMenuItem<int>> items = [];
    variants.asMap().forEach(
          (k, v) => items.add(DropdownMenuItem(value: k, child: Text(v.name))),
        );
    return items;
  }

  static int variant = 0;
  void _setVariant(int? v) => setState(() => variant = v ?? variant);

  // 0 - white, 1 - random, 2 - black
  static int colour = 1;
  void _changeColour(int c) => setState(() => colour = c);

  static OpponentType opponentType = OpponentType.ai;
  void _changeOpponent(OpponentType type) =>
      setState(() => opponentType = type);

  void _create() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      int _colour = colour == 0
          ? 0
          : colour == 2
              ? 1
              : Random().nextInt(2);
      if (fen?.isEmpty ?? false) fen = null;
      final config = GameConfig(
        variant: variants[variant],
        humanPlayer: _colour,
        opponentType: opponentType,
        fen: fen,
      );
      widget.onCreate(config);
    }
  }

  final _formKey = GlobalKey<FormState>();

  static String? fen;
  final TextEditingController _fenController = TextEditingController(text: fen);

  bool _validateFen(String fen, bishop.Variant? variant) {
    variant ??= bishop.Variant.standard();
    return bishop.validateFen(variant: variant, fen: fen);
  }

  void _clearFen() {
    _fenController.clear();
    setState(() => fen = null);
  }

  Future<void> _goToBoardEditor() async {
    if (_formKey.currentState!.validate()) {
      String? fen = await Navigator.of(context).push<String?>(
        MaterialPageRoute(
          builder: (context) => BoardEditorView(
            variant: variants[variant],
            initialFen:
                _fenController.text.isNotEmpty ? _fenController.text : null,
          ),
        ),
      );
      if (fen != null) {
        setState(() {
          _fenController.text = fen;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          Container(height: 32),
          Text(
            'Game Setup',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const Divider(),
          DropdownButton<int>(
            value: variant,
            items: _variantDropdownItems,
            onChanged: _setVariant,
          ),
          ToggleButtons(
            children: [
              SizedBox(
                width: 32,
                height: 32,
                child: FittedBox(child: widget.pieceSet.piece(context, 'K')),
              ),
              const Icon(
                MdiIcons.helpCircleOutline,
                size: 30,
              ),
              SizedBox(
                width: 32,
                height: 32,
                child: FittedBox(child: widget.pieceSet.piece(context, 'k')),
              ),
            ],
            isSelected: [colour == 0, colour == 1, colour == 2],
            onPressed: _changeColour,
          ),
          DropdownButton<OpponentType>(
            value: opponentType,
            items: OpponentType.values
                .map((e) => DropdownMenuItem(value: e, child: Text(e.title)))
                .toList(),
            onChanged: (v) => _changeOpponent(v ?? OpponentType.ai),
          ),
          ElevatedButton(
            onPressed: _create,
            child: const Text('Create Game'),
          ),
        ],
      ),
    );
  }
}
